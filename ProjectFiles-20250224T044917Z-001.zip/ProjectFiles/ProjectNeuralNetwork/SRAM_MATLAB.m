modelPath = 'sram_model.h5';  % Update this path if necessary
net = importTensorFlowNetwork(modelPath, 'OutputLayerType', 'classification');
disp('Model successfully loaded!');