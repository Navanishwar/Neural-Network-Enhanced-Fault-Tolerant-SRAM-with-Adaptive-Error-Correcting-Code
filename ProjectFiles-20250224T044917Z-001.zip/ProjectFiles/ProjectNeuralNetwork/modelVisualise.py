import numpy as np
from tensorflow.keras.models import load_model
from sklearn.metrics import roc_curve, auc, confusion_matrix, ConfusionMatrixDisplay, classification_report
import matplotlib.pyplot as plt
import pandas as pd

# Load the trained model
model = load_model('sram_model.h5')

# Load test data (replace with your actual test data loading code)
try:
    df = pd.read_excel('sram_dataset.xlsx')
except FileNotFoundError:
    print("Error: 'sram_dataset.xlsx' not found. Please upload the file.")
    exit()

# Helper function to convert binary strings to arrays
def binary_to_array(binary_string, length):
    binary_string = str(binary_string).zfill(length)  # Ensure it's a string and pad to the correct length
    return np.array([int(bit) for bit in binary_string])

# Preprocess data
X_test = []
y_test = []
for index, row in df.iterrows():
    try:
        corrupted_data_array = binary_to_array(row['Corrupted Data'], 8)
        syndrome_array = binary_to_array(row['Syndrome'], 4)
        corrected_data_array = binary_to_array(row['Corrected Data'], 8)
        
        X_test.append(np.concatenate((corrupted_data_array, syndrome_array)))
        y_test.append(corrected_data_array)
    except ValueError as e:
        continue

X_test = np.array(X_test)
y_test = np.array(y_test)

# Make predictions
y_pred = model.predict(X_test, verbose=0)

# Convert predictions to binary format (threshold = 0.5)
y_pred_binary = (y_pred > 0.5).astype(int)

# Confusion Matrix
conf_matrix = confusion_matrix(y_test.argmax(axis=1), y_pred_binary.argmax(axis=1))
ConfusionMatrixDisplay(conf_matrix).plot(cmap='Blues')
plt.title("Confusion Matrix")
plt.show()

# ROC Curve and AUC
fpr = dict()
tpr = dict()
roc_auc = dict()
for i in range(y_test.shape[1]):
    fpr[i], tpr[i], _ = roc_curve(y_test[:, i], y_pred[:, i])
    roc_auc[i] = auc(fpr[i], tpr[i])

# Plot ROC Curve
for i in range(y_test.shape[1]):
    plt.plot(fpr[i], tpr[i], label=f"Bit {i} (AUC = {roc_auc[i]:.2f})")

plt.plot([0, 1], [0, 1], 'k--')  # Random classifier line
plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.title("ROC Curve")
plt.legend(loc="lower right")
plt.show()

# Print Summary Only
print("\nModel Evaluation Complete. Key Metrics:")
print(f"Overall AUC: {np.mean(list(roc_auc.values())):.2f}")
