import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense,Dropout
import keras

# Load the dataset
try:
    df = pd.read_excel('sram_dataset.xlsx')
except FileNotFoundError:
    print("Error: 'sram_dataset.xlsx' not found. Please upload the file.")
    from google.colab import files
    uploaded = files.upload()
    df = pd.read_excel(list(uploaded.keys())[0])

# Preprocess the data
def binary_to_array(binary_string, length):
    binary_string = str(binary_string).zfill(length)  # Ensure binary string has correct length
    return np.array([int(bit) for bit in binary_string])

X = []
y = []

for _, row in df.iterrows():
    corrupted_data = binary_to_array(row['Corrupted Data'], 8)
    syndrome = binary_to_array(row['Syndrome'], 4)
    corrected_data = binary_to_array(row['Corrected Data'], 8)

    X.append(np.concatenate((corrupted_data, syndrome)))
    y.append(corrected_data)

X = np.array(X)
y = np.array(y)

# Split data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Build the neural network model
model = Sequential()
model.add(Dense(256, activation='relu', input_dim=12))  # Input layer with more neurons
model.add(Dense(128,activation='relu'))
model.add(Dense(128,activation='relu'))
model.add(Dense(64,activation='relu'))
model.add(Dense(64,activation='relu'))
model.add(Dense(64, activation='relu'))  # Hidden layer 1
model.add(Dense(64, activation='relu'))  # Hidden layer 2
model.add(Dense(64,activation='relu'))
model.add(Dense(64,activation='relu'))
model.add(Dense(64,activation='relu'))
model.add(Dense(64,activation='relu'))
model.add(Dense(64,activation='relu'))
model.add(Dense(64, activation='relu'))  # Hidden layer 1
model.add(Dense(64, activation='relu'))  # Hidden layer 2
model.add(Dense(64,activation='relu'))
model.add(Dense(8, activation='sigmoid'))  # Output layer


# Compile the model
optimizer= keras.optimizers.Adam(learning_rate=0.1)
model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])

# Print model summary
model.summary()

# Train the model
model.fit(X_train, y_train, epochs=30, batch_size=32, verbose=2)  # Suppressed verbose for cleaner output

# Evaluate the model
_, accuracy = model.evaluate(X_test, y_test, verbose=0)
print(f"\nTest Accuracy: {accuracy * 100:.2f}%")

# Save the model
model.save('sram_model.h5')
